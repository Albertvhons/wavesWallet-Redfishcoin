package com.wavesplatform.wallet.ui.base;

public interface ViewModel {

    void destroy();

}
