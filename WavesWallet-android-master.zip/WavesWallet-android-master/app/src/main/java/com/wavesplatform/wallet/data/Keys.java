package com.wavesplatform.wallet.data;

public class Keys {

    public static final String KEY_PAIR_MODEL = "pair_model";
    public static final String KEY_AMOUNT_ASSET_ID = "amount_asset_id";
    public static final String KEY_AMOUNT_ASSET_NAME = "amount_asset_name";
    public static final String KEY_PRICE_ASSET_ID = "price_asset_id";
    public static final String KEY_PRICE_ASSET_NAME = "price_asset_name";
}
