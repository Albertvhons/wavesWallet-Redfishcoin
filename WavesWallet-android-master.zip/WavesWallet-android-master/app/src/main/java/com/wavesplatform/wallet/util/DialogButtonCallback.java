package com.wavesplatform.wallet.util;


public interface DialogButtonCallback {

    void onPositiveClicked();

    void onNegativeClicked();
}
