package com.wavesplatform.wallet.ui.home;

public interface TransactionSelectedListener {

    void onScrollToTop();

}
