package com.wavesplatform.wallet.data.auth;

public class IncorrectPinException extends RuntimeException {
}
