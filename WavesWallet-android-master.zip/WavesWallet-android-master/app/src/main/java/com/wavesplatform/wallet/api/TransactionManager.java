package com.wavesplatform.wallet.api;

public class TransactionManager {
}
