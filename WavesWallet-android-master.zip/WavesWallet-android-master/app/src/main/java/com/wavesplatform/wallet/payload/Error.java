package com.wavesplatform.wallet.payload;

/**
 * Created by anonymous on 04.07.17.
 */

public class Error {
    public String status;
    public String message = "Something went wrong...";
}
