package com.wavesplatform.wallet.ui.customviews;

public interface CustomKeypadCallback {

    void onKeypadClose();

    void onKeypadOpen();

    void onKeypadOpenCompleted();
}