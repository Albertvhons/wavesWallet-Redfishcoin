package com.wavesplatform.wallet.payload;

import java.util.ArrayList;

public class Markets {
    public String matcherPublicKey;
    public ArrayList<Market> markets = new ArrayList<>();
}
